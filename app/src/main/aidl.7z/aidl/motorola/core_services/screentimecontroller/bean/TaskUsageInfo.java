package motorola.core_services.screentimecontroller.bean;

import android.os.Bundle;

import motorola.core_services.screentimecontroller.ScreenTimeControllerHelper;

public class TaskUsageInfo {

    private String packageName;
    private String uid;
    private long startTime;
    private long duration;

    public TaskUsageInfo() {
    }

    protected TaskUsageInfo(Bundle bundle) {
        packageName = bundle.getString(ScreenTimeControllerHelper.TaskUsageInfo.PACKAGE_NAME, getPackageName());
        uid = bundle.getString(ScreenTimeControllerHelper.TaskUsageInfo.PACKAGE_UID, getUid());
        startTime = bundle.getLong(ScreenTimeControllerHelper.TaskUsageInfo.START_TIME, getStartTime());
        duration = bundle.getLong(ScreenTimeControllerHelper.TaskUsageInfo.DURATION, getDuration());
    }

    public Bundle toBundle() {
        Bundle bundle = new Bundle();
        bundle.putString(ScreenTimeControllerHelper.TaskUsageInfo.PACKAGE_NAME, getPackageName());
        bundle.putString(ScreenTimeControllerHelper.TaskUsageInfo.PACKAGE_UID, getUid());
        bundle.putLong(ScreenTimeControllerHelper.TaskUsageInfo.START_TIME, getStartTime());
        bundle.putLong(ScreenTimeControllerHelper.TaskUsageInfo.DURATION, getDuration());
        return bundle;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public String getInfo() {
        return "TaskUsageInfo{" +
                "packageName='" + packageName + '\'' +
                ", uid='" + uid + '\'' +
                ", startTime=" + startTime +
                ", duration=" + duration +
                '}';
    }
}