package motorola.core_services.screentimecontroller.database.config;

import motorola.core_services.screentimecontroller.bean.BaseColumn;

public class ScreenBlockUpTimeTable extends BaseColumn {
    // 表名
    public static final String TABLE_NAME = "screen_limit_time";
    // 禁止起始时间
    public static String START_TIME = "start_time";
    // 禁止终止时间
    public static String END_TIME = "end_time";
}