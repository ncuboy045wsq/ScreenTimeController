package motorola.core_services.screentimecontroller.database.dao;

import java.util.List;

public interface BaseDao<T> {

    long insert(T t);

    T query(T t);

    List<T> query();

    int update(T screenUsageInfo);

    int delete(T screenUsageInfo);
}
