package motorola.core_services.screentimecontroller.bean;

public class BaseColumn {
    public static final String _ID = "_id";
}
