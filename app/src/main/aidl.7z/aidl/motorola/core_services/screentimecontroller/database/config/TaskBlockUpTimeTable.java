package motorola.core_services.screentimecontroller.database.config;

import motorola.core_services.screentimecontroller.bean.BaseColumn;

public class TaskBlockUpTimeTable extends BaseColumn {
    // 表名
    public static final String TABLE_NAME = "task_usage_limit";
    // 应用包名
    public static final String PACKAGE_NAME = "package_name";
    // 应用 uid
    public static final String UID = "uid";
    // 用户 id
    public static final String USER_ID = "user_id";
    // 应用单日最大使用时长(0为黑名单/应用锁)
    public static final String MAX_USAGE = "max_usage";
    // 应用单日最大使用时长(0为黑名单/应用锁)
    public static final String BLOCK_TYPE = "block_type";
}
