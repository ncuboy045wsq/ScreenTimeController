package motorola.core_services.screentimecontroller.database.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import motorola.core_services.screentimecontroller.bean.TaskBlockUpInfo;

import motorola.core_services.screentimecontroller.database.config.TaskBlockUpTimeTable;

import java.util.ArrayList;
import java.util.List;

public class TaskBlockUpDao implements BaseDao<TaskBlockUpInfo> {

    // 表名
    public static final String TABLE_NAME = TaskBlockUpTimeTable.TABLE_NAME;

    private final SQLiteDatabase mSqLiteDatabase;

    public TaskBlockUpDao(SQLiteDatabase sqLiteDatabase) {
        this.mSqLiteDatabase = sqLiteDatabase;
    }

    private ContentValues getInsertContentValues(TaskBlockUpInfo taskBlockUpInfo) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(TaskBlockUpTimeTable.PACKAGE_NAME, taskBlockUpInfo.getPackageName());
        contentValues.put(TaskBlockUpTimeTable.UID, taskBlockUpInfo.getUid());
        contentValues.put(TaskBlockUpTimeTable.USER_ID, taskBlockUpInfo.getUserId());
        contentValues.put(TaskBlockUpTimeTable.MAX_USAGE, taskBlockUpInfo.getMaxUsage());
        contentValues.put(TaskBlockUpTimeTable.BLOCK_TYPE, taskBlockUpInfo.getBlockType());
        return contentValues;
    }

    @Override
    public long insert(TaskBlockUpInfo taskBlockUpInfo) {
        ContentValues contentValues = getInsertContentValues(taskBlockUpInfo);
        return mSqLiteDatabase.insert(TaskBlockUpTimeTable.TABLE_NAME, null, contentValues);
    }

    @Override
    public TaskBlockUpInfo query(TaskBlockUpInfo taskUsageInfo) {
        String selection = TaskBlockUpTimeTable.PACKAGE_NAME + "=? AND " + TaskBlockUpTimeTable.UID + "=?";
        String[] selectionArgs = new String[]{taskUsageInfo.getPackageName(), taskUsageInfo.getUid()};
        Cursor cursor = mSqLiteDatabase.query(TaskBlockUpTimeTable.TABLE_NAME, null, selection, selectionArgs, null, null, null);
        TaskBlockUpInfo taskBlockUpInfoResult = null;
        if (cursor.moveToNext()) {
            taskBlockUpInfoResult = getTaskBlockUpInfo(cursor);
        }
        return taskBlockUpInfoResult;
    }

    @Override
    public List<TaskBlockUpInfo> query() {

        Cursor cursor = mSqLiteDatabase.query(TaskBlockUpTimeTable.TABLE_NAME, null, null, null, null, null, null);

        List<TaskBlockUpInfo> taskBlockUpInfoList = new ArrayList<>();

        while (cursor.moveToNext()) {
            taskBlockUpInfoList.add(getTaskBlockUpInfo(cursor));
        }

        return taskBlockUpInfoList;
    }

    private TaskBlockUpInfo getTaskBlockUpInfo(Cursor cursor) {
        TaskBlockUpInfo taskBlockUpInfoResult;
        taskBlockUpInfoResult = new TaskBlockUpInfo();
        taskBlockUpInfoResult.setPackageName(cursor.getString(cursor.getColumnIndex(TaskBlockUpTimeTable.PACKAGE_NAME)));
        taskBlockUpInfoResult.setUid(cursor.getString(cursor.getColumnIndex(TaskBlockUpTimeTable.UID)));
        taskBlockUpInfoResult.setUserId(cursor.getString(cursor.getColumnIndex(TaskBlockUpTimeTable.USER_ID)));
        taskBlockUpInfoResult.setMaxUsage(cursor.getLong(cursor.getColumnIndex(TaskBlockUpTimeTable.MAX_USAGE)));
        taskBlockUpInfoResult.setBlockType(cursor.getInt(cursor.getColumnIndex(TaskBlockUpTimeTable.BLOCK_TYPE)));
        return taskBlockUpInfoResult;
    }

    @Override
    public int update(TaskBlockUpInfo taskBlockUpInfo) {

        String where;
        String[] selectionArgs;

        where = TaskBlockUpTimeTable.PACKAGE_NAME + "=? and " + TaskBlockUpTimeTable.UID + "=?";
        selectionArgs = new String[]{taskBlockUpInfo.getPackageName(), taskBlockUpInfo.getUid()};

        return mSqLiteDatabase.update(TaskBlockUpTimeTable.TABLE_NAME, getInsertContentValues(taskBlockUpInfo), where, selectionArgs);
    }

    @Override
    public int delete(TaskBlockUpInfo taskBlockUpInfo) {
        String where;
        String[] selectionArgs;

        where = TaskBlockUpTimeTable.PACKAGE_NAME + "=? and " + TaskBlockUpTimeTable.UID + "=?";
        selectionArgs = new String[]{taskBlockUpInfo.getPackageName(), taskBlockUpInfo.getUid()};

        return mSqLiteDatabase.delete(TaskBlockUpTimeTable.TABLE_NAME, where, selectionArgs);
    }

}