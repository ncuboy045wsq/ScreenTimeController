package motorola.core_services.screentimecontroller.database.dao;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import motorola.core_services.screentimecontroller.bean.ScreenBlockUpTime;
import motorola.core_services.screentimecontroller.database.config.ScreenBlockUpTimeTable;

import java.util.ArrayList;
import java.util.List;

public class ScreenBlockUpDao implements BaseDao<ScreenBlockUpTime> {

    // 表名
    public static final String TABLE_NAME = ScreenBlockUpTimeTable.TABLE_NAME;

    private final SQLiteDatabase mSqLiteDatabase;

    public ScreenBlockUpDao(SQLiteDatabase sqLiteDatabase) {
        this.mSqLiteDatabase = sqLiteDatabase;
    }

    @Override
    public long insert(ScreenBlockUpTime screenBlockupTime) {
        ContentValues contentValues = getInsertContentValues(screenBlockupTime);
        return mSqLiteDatabase.insert(TABLE_NAME, null, contentValues);
    }

    private ContentValues getInsertContentValues(ScreenBlockUpTime screenBlockupTime) {
        ContentValues contentValues = new ContentValues();
        if (screenBlockupTime != null) {
            contentValues.put(ScreenBlockUpTimeTable.START_TIME, screenBlockupTime.getStartTime());
            contentValues.put(ScreenBlockUpTimeTable.END_TIME, screenBlockupTime.getEndTime());
        }
        return contentValues;
    }

    @Override
    public ScreenBlockUpTime query(ScreenBlockUpTime blockupTime) {
        return null;
    }

    @Override
    public List<ScreenBlockUpTime> query() {
        Cursor cursor = mSqLiteDatabase.query(ScreenBlockUpTimeTable.TABLE_NAME, null, null, null, null, null, null);
        List<ScreenBlockUpTime> screenBlockUpTimeList = new ArrayList<>();
        while (cursor != null && cursor.moveToNext()) {
            ScreenBlockUpTime screenBlockUpTime = new ScreenBlockUpTime();
            screenBlockUpTime.setStartTime(cursor.getLong(cursor.getColumnIndex(ScreenBlockUpTimeTable.START_TIME)));
            screenBlockUpTime.setEndTime(cursor.getLong(cursor.getColumnIndex(ScreenBlockUpTimeTable.END_TIME)));
            screenBlockUpTimeList.add(screenBlockUpTime);
        }
        return screenBlockUpTimeList;
    }

    @Override
    public int update(ScreenBlockUpTime screenUsageInfo) {

        String where;
        String[] selectionArgs;

        where = ScreenBlockUpTimeTable._ID + "=?";
        selectionArgs = new String[]{screenUsageInfo.getId() + ""};

        return mSqLiteDatabase.update(ScreenBlockUpTimeTable.TABLE_NAME, getInsertContentValues(screenUsageInfo), where, selectionArgs);
    }

    @Override
    public int delete(ScreenBlockUpTime screenUsageInfo) {
        String where;
        String[] selectionArgs;

        where = ScreenBlockUpTimeTable._ID + "=?";
        selectionArgs = new String[]{screenUsageInfo.getId() + ""};

        return mSqLiteDatabase.delete(ScreenBlockUpTimeTable.TABLE_NAME, where, selectionArgs);
    }

}