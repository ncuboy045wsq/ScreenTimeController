package motorola.core_services.screentimecontroller;

public class ScreenTimeControllerHelper {

    // screen block up time
    public static class ScreenBlockUpTime {
        public static final String ID = "ID";
        public static final String START_TIME = "START_TIME";
        public static final String END_TIME = "END_TIME";
    }


    // task block up time
    public static class TaskBlockUpTime {
        public static final String PACKAGE_NAME = "PACKAGE_NAME";
        public static final String PACKAGE_UID = "UID";
        public static final String PACKAGE_USER_ID = "user_id";
        public static final String MAX_USAGE = "MAX_USAGE";
        public static final String BLOCK_TYPE = "ALWAYS_ALLOW";
    }


    // task usage information
    public static class TaskUsageInfo {
        public static final String PACKAGE_NAME = "PACKAGE_NAME";
        public static final String PACKAGE_UID = "UID";
        public static final String START_TIME = "START_TIME";
        public static final String DURATION = "DURATION";
    }
}