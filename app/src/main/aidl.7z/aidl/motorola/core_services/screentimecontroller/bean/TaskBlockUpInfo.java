package motorola.core_services.screentimecontroller.bean;

import android.os.Bundle;

import motorola.core_services.screentimecontroller.ScreenTimeControllerHelper;

/**
 * APP 先
 */
public class TaskBlockUpInfo {

    public interface BLOCK_TYPE {
        int TYPE_MAX_USAGE = 1;
        int TYPE_MAX_ALWAYS_ALLOW = 2;
    }

    /**
     * 应用名称
     */
    private String packageName;

    /**
     * 应用的 UID
     */
    private String uid;

    /**
     * 用户 id
     */
    private String userId;

    /**
     * 任务停用起始时间
     */
    private long maxUsage;

    /**
     * 限制方式: 1: 最大使用时长规则, 2: 总是允许使用
     */
    private int blockType;

    public TaskBlockUpInfo() {
    }

    public TaskBlockUpInfo(Bundle bundle) {
        packageName = bundle.getString(ScreenTimeControllerHelper.TaskBlockUpTime.PACKAGE_NAME, getPackageName());
        uid = bundle.getString(ScreenTimeControllerHelper.TaskBlockUpTime.PACKAGE_UID, getUid());
        userId = bundle.getString(ScreenTimeControllerHelper.TaskBlockUpTime.PACKAGE_USER_ID, getUserId());
        maxUsage = bundle.getLong(ScreenTimeControllerHelper.TaskBlockUpTime.MAX_USAGE, getMaxUsage());
        blockType = bundle.getInt(ScreenTimeControllerHelper.TaskBlockUpTime.BLOCK_TYPE, getBlockType());
    }

    public Bundle toBundle() {
        Bundle bundle = new Bundle();
        bundle.putString(ScreenTimeControllerHelper.TaskBlockUpTime.PACKAGE_NAME, getPackageName());
        bundle.putString(ScreenTimeControllerHelper.TaskBlockUpTime.PACKAGE_UID, getUid());
        bundle.putString(ScreenTimeControllerHelper.TaskBlockUpTime.PACKAGE_UID, getUserId());
        bundle.putLong(ScreenTimeControllerHelper.TaskBlockUpTime.MAX_USAGE, getMaxUsage());
        bundle.putInt(ScreenTimeControllerHelper.TaskBlockUpTime.BLOCK_TYPE, getBlockType());
        return bundle;
    }

    /**
     * 返回应用的
     *
     * @return
     */
    public String getIdentity() {
        String packageName = this.packageName == null ? "" : this.packageName;
        String userId = this.userId == null ? "" : this.userId;
        return packageName + "_" + userId;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public long getMaxUsage() {
        return maxUsage;
    }

    public void setMaxUsage(long maxUsage) {
        this.maxUsage = maxUsage;
    }

    public int getBlockType() {
        return blockType;
    }

    public void setBlockType(int blockType) {
        this.blockType = blockType;
    }
}
