package motorola.core_services.screentimecontroller.bean;

import android.os.Bundle;

import motorola.core_services.screentimecontroller.ScreenTimeControllerHelper;

public class ScreenBlockUpTime {

    private long id;
    /**
     * 任务停用起始时间
     */
    private long startTime;
    /**
     * 任务停用结束时间
     */
    private long endTime;

    public ScreenBlockUpTime() {
    }

    public ScreenBlockUpTime(Bundle bundle) {
        id = bundle.getLong(ScreenTimeControllerHelper.ScreenBlockUpTime.ID, getId());
        startTime = bundle.getLong(ScreenTimeControllerHelper.ScreenBlockUpTime.START_TIME, getStartTime());
        endTime = bundle.getLong(ScreenTimeControllerHelper.ScreenBlockUpTime.END_TIME, getEndTime());
    }

    public Bundle toBundle() {
        Bundle bundle = new Bundle();
        bundle.putLong(ScreenTimeControllerHelper.ScreenBlockUpTime.ID, getId());
        bundle.putLong(ScreenTimeControllerHelper.ScreenBlockUpTime.START_TIME, getStartTime());
        bundle.putLong(ScreenTimeControllerHelper.ScreenBlockUpTime.END_TIME, getEndTime());
        return bundle;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }
}
