package motorola.core_services.screentimecontroller.database;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import motorola.core_services.screentimecontroller.database.config.ScreenBlockUpTimeTable;
import motorola.core_services.screentimecontroller.database.config.TaskBlockUpTimeTable;

public class ScreenTimeControllerDBOpenHelper extends SQLiteOpenHelper {

    // If you change the database schema, you must increment the database version.
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "screen_time_controller.db";


    private static final String SQL_CREATE_SCREEN_BLOCK_UP_TIME_ENTRIES =
            "CREATE TABLE IF NOT EXISTS " + ScreenBlockUpTimeTable.TABLE_NAME + " (" +
                    ScreenBlockUpTimeTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    ScreenBlockUpTimeTable.START_TIME + " TEXT," +
                    ScreenBlockUpTimeTable.END_TIME + " TEXT)";

    private static final String SQL_CREATE_TASK_BLOCK_UP_INFO_ENTRIES =
            "CREATE TABLE IF NOT EXISTS " + TaskBlockUpTimeTable.TABLE_NAME + " (" +
                    TaskBlockUpTimeTable.PACKAGE_NAME + " TEXT," +
                    TaskBlockUpTimeTable.UID + " TEXT," +
                    TaskBlockUpTimeTable.USER_ID + " TEXT," +
                    TaskBlockUpTimeTable.MAX_USAGE + " INTEGER," +
                    TaskBlockUpTimeTable.BLOCK_TYPE + " BOOLEAN," +
                    "PRIMARY KEY (" + TaskBlockUpTimeTable.PACKAGE_NAME + ", " + TaskBlockUpTimeTable.UID + "))";

    private static final String SQL_DELETE_SCREEN_BLOCK_UP_TIME_ENTRIES = "DROP TABLE IF EXISTS " + ScreenBlockUpTimeTable.TABLE_NAME;
    private static final String SQL_DELETE_TASK_BLOCK_UP_INFO_EENTRIES = "DROP TABLE IF EXISTS " + TaskBlockUpTimeTable.TABLE_NAME;

    public ScreenTimeControllerDBOpenHelper( Context context) {
        this(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private ScreenTimeControllerDBOpenHelper( Context context,  String name,  SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    private ScreenTimeControllerDBOpenHelper( Context context,  String name,  SQLiteDatabase.CursorFactory factory, int version,  DatabaseErrorHandler errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    private ScreenTimeControllerDBOpenHelper( Context context,  String name, int version,  SQLiteDatabase.OpenParams openParams) {
        super(context, name, version, openParams);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_SCREEN_BLOCK_UP_TIME_ENTRIES);
        db.execSQL(SQL_CREATE_TASK_BLOCK_UP_INFO_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (newVersion == oldVersion) {
            return;
        }

        db.execSQL(SQL_DELETE_SCREEN_BLOCK_UP_TIME_ENTRIES);
        db.execSQL(SQL_DELETE_TASK_BLOCK_UP_INFO_EENTRIES);

        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        super.onDowngrade(db, oldVersion, newVersion);
        onUpgrade(db, oldVersion, newVersion);
    }

}