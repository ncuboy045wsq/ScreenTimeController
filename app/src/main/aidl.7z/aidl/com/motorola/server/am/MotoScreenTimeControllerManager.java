package com.motorola.server.am;


import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.IBinder;

//import android.util.Slog;
//import com.android.server.FgThread;

import java.util.List;

import motorola.core_services.screentimecontroller.bean.ScreenBlockUpTime;
import motorola.core_services.screentimecontroller.bean.TaskBlockUpInfo;
import motorola.core_services.screentimecontroller.database.ScreenTimeControllerDBOpenHelper;
import motorola.core_services.screentimecontroller.database.dao.ScreenBlockUpDao;
import motorola.core_services.screentimecontroller.database.dao.TaskBlockUpDao;

public class MotoScreenTimeControllerManager {

    private static final String TAG = "MotoScreenTimeControllerManager";

    private static final String MOTO_SYSTEM_SERVER_ACTION = "com.com.motorola.screentimecontroller.screentimecontrollerservice";
    private static final String MOTO_SYSTEM_SERVER_PKG = "com.com.motorola.screentimecontroller";

    private static MotoScreenTimeControllerManager mInstance = null;
    private Context mContext = null;
    private Intent mIntent;
    private Handler mHandler = null; //new Handler(FgThread.get().getLooper());
    private Connection mConnection;
    private int mCurrentUser;

    private SQLiteDatabase mScreenTimeControllerDB;
    private ScreenBlockUpDao mScreenBlockUpDao;
    private TaskBlockUpDao mTaskBlockUpDao;

    public static MotoScreenTimeControllerManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new MotoScreenTimeControllerManager(context);
        }
        return mInstance;
    }

    private MotoScreenTimeControllerManager(Context context) {
        mContext = context;
        mIntent = new Intent();
        mIntent.setAction(MOTO_SYSTEM_SERVER_ACTION);
        mIntent.setPackage(MOTO_SYSTEM_SERVER_PKG);

        ScreenTimeControllerDBOpenHelper screenTimeControllerDBOpenHelper = new ScreenTimeControllerDBOpenHelper(context);
        mScreenTimeControllerDB = screenTimeControllerDBOpenHelper.getWritableDatabase();
        mScreenBlockUpDao = new ScreenBlockUpDao(mScreenTimeControllerDB);
        mTaskBlockUpDao = new TaskBlockUpDao(mScreenTimeControllerDB);
    }

    public void bindMotoScreenTimeControllerServer(int userId) {

//        Slog.d(TAG, "bindMotoScreenTimeControllerServer: userId = " + userId);

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                mCurrentUser = userId;
                unbindLocked(mConnection);
                bindLocked();
            }
        });
    }

    private void bindLocked() {
        if (mConnection != null && mConnection.mBound && mConnection.mUserId == mCurrentUser) {
            return;
        }
        mConnection = new Connection(mCurrentUser);
//        Slog.d(TAG,"bind moto screen time controller server: userId = " + mCurrentUser);
        // lk_test
//        mContext.bindServiceAsUser(mIntent, mConnection, Context.BIND_AUTO_CREATE, UserHandle.of(mCurrentUser));
    }

    private void unbindLocked(Connection connection) {
        if (connection != null) {
//            Slog.d(TAG, "unbind moto screen time controller server: userId = " + connection.mUserId);
            try {
                mContext.unbindService(connection);
            } catch (IllegalArgumentException e) {
//                Slog.e(TAG, "Exception trying to unbind moto screen time controller server: " + e.getMessage());
            }
        }
    }

    private class Connection implements ServiceConnection {

        private int mUserId;
        private volatile boolean mBound;

        public Connection(int userId) {
            mUserId = userId;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
//            Slog.d(TAG, "Connected to service : " + name.flattenToString() + ", userId = " + mUserId);
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
//            Slog.d(TAG,"Service " + name.flattenToString() + " disconnected" + ", userId = " + mUserId);
            startScreenTimeControllerService();
        }

        @Override
        public void onBindingDied(ComponentName name) {
            startScreenTimeControllerService();
        }

        private void startScreenTimeControllerService() {
            mBound = false;
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    unbindLocked(Connection.this);
                    if (mCurrentUser == mUserId) {
                        bindLocked();
                    }
                }
            });
        }

    }

    // ====>
    // BEGIN Motorola, linkang, 2021-07-29
    public void addScreenBlockUpTime(ScreenBlockUpTime screenBlockUpTime) {
        mScreenBlockUpDao.insert(screenBlockUpTime);
    }

    public void updateScreenBlockUpTime(ScreenBlockUpTime screenBlockupTime) {
        mScreenBlockUpDao.update(screenBlockupTime);
    }

    public void addTaskBlockUpInfo(TaskBlockUpInfo taskBlockupInfo) {
        mTaskBlockUpDao.insert(taskBlockupInfo);
    }

    public void updateScreenBlockUpTime(TaskBlockUpInfo taskBlockupInfo) {
        mTaskBlockUpDao.update(taskBlockupInfo);
    }

    public List<TaskBlockUpInfo> getTaskBlockUpInfos() {
        return mTaskBlockUpDao.query();
    }

    public List<ScreenBlockUpTime> getScreenBlockUpTimes() {
        return mScreenBlockUpDao.query();
    }

}